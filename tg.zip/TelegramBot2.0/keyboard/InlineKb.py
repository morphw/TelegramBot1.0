from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

ikm1 = InlineKeyboardMarkup(row_width=1)
ikb1 = InlineKeyboardButton(text='🛒Каталог', callback_data='catalog')
ikm1.add(ikb1)

ikm2 = InlineKeyboardMarkup(row_width=1)
ikb2 = InlineKeyboardButton(text='1.Пополнение Steam кошелька💰', callback_data='pay_steam')
ikb_otzivi = InlineKeyboardButton(text='Отзывы', url='https://vk.com/topic-204266015_49152633')
ikm2.add(ikb2, ikb_otzivi)

ikm3 = InlineKeyboardMarkup(row_width=1)
ikb3 = InlineKeyboardButton(text='✒Своя сумма (15-18%)', callback_data='my_summ')
ikb3_1 = InlineKeyboardButton(text='💶Фиксированная сумма (10-13%)', callback_data='fix_summ')
ikm3.add(ikb3)

ikm4 = InlineKeyboardMarkup(row_width=1)
ikb4 = InlineKeyboardButton(text='Карта💳(15%)', callback_data='card')
ikb4_1 = InlineKeyboardButton(text='Киви🥝(18%)', callback_data='qiwi')
ikm4.add(ikb4, ikb4_1)
