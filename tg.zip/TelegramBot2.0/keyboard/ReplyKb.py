from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

menu_catalog = KeyboardButton('🛒Каталог')
menu_info = KeyboardButton('❓Инормация')
main_menu = ReplyKeyboardMarkup(resize_keyboard=True).add(menu_catalog, menu_info)
