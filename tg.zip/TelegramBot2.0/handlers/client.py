from aiogram import types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup

from config import INM_INFO, INM_STORE, INM_CATALOG, INM_PAYMENT
from create_bot import bot, dp
from keyboard.InlineKb import ikm2, ikm4
from keyboard.ReplyKb import main_menu

storage = MemoryStorage()


class FSMsumm(StatesGroup):
    summ = State()
    summ2 = State()


async def start_message(message: types.message):
    user_name = message.from_user.full_name
    await bot.send_photo(message.from_user.id,
                         photo=INM_STORE,
                         caption=f'👋Приветствую, {user_name}! '
                                 f'\n⚡Это Бот INM Store⚡',
                         reply_markup=main_menu)
    await message.delete()


async def message_catalog(message: types.message):
    if message.text in "🛒Каталог":
        await bot.send_photo(message.from_user.id,
                             photo=INM_CATALOG,
                             caption='🛒Каталог: \n\n'
                                     '📌1.Пополнение кошелька Steam💰 \n'
                                     '📌2.В разработке🛠  \n\n'
                                     '📚Выберете услугу или товар:',
                             reply_markup=ikm2)


async def callback_pay_steam(callback: types.callback_query):
    await bot.send_photo(callback.from_user.id,
                         photo=INM_PAYMENT,
                         caption='📱Выберете способ оплаты:',
                         reply_markup=ikm4)


async def callback_qiwi(callback: types.callback_query):
    await FSMsumm.summ2.set()
    await bot.send_photo(callback.from_user.id,
                         photo=INM_STORE,
                         caption='✏Введите сумму пополнения от 100₽:')


async def message_summ2(message: types.message, state: FSMContext):
    async with state.proxy() as data:
        try:
            data['summ'] = float(message.text)
            if data['summ'] >= 100:
                user_summ = data['summ'] / 100 * 18 + data['summ']
                async with state.proxy() as data:
                    await bot.send_photo(message.from_user.id,
                                         photo=INM_INFO,
                                         caption='❗ВАЖНО: СКРИНШОТ ОПЛАТЫ И ВАШ ЛОГИН ПРЕДОСТАВЬТЕ:@fourthgg❗\n\n'
                                                 '⌚Деньги придут вам на кошелек steam в течении 24-х часов\n\n'
                                                 '💵Комиссия (18%)\n\n'
                                                 'Внимание! сумма зачисления в рублях будет всегда '
                                                 'меньше суммы пополнения, ввиду дополнительных конвертаций в валюты  '
                                                 'других стран, так как прямого пополнения стим в РФ нет.\n\n'
                                                 f'Оплатите {user_summ}₽ на любую из представленных карт: \n\n'
                                                 '💳СберБанк: 2202203259212399\n'
                                                 '💳Тинькофф: 5536914196764892',)
            elif data['summ'] <= 99:
                async with state.proxy() as data:
                    await bot.send_message(message.from_user.id,
                                           text='Введите сумму от 100р:')
                    await state.reset()
        except ValueError:
            await bot.send_message(message.from_user.id,
                                   text='Введите число:')
            await state.reset()

    await state.finish()


async def callback_card(callback: types.callback_query):
    await FSMsumm.summ.set()
    await bot.send_photo(callback.from_user.id,
                         photo=INM_STORE,
                         caption='✏Введите сумму пополнения от 100₽:')


async def message_summ(message: types.message, state: FSMContext):
    async with state.proxy() as data:
        try:
            data['summ'] = float(message.text)
            markup = types.ReplyKeyboardRemove()
            if data['summ'] >= 100:
                user_summ = data['summ'] / 100 * 15 + data['summ']
                async with state.proxy() as data:
                    await bot.send_photo(message.from_user.id,
                                         photo=INM_INFO,
                                         caption='❗ВАЖНО: СКРИНШОТ ОПЛАТЫ И ВАШ ЛОГИН ПРЕДОСТАВЬТЕ:@fourthgg❗\n\n'
                                                 '⌚Деньги придут вам на кошелек steam в течении 24-х часов\n\n'
                                                 '💵Комиссия (15%)\n\n'
                                                 'Внимание! сумма зачисления в рублях будет всегда '
                                                 'меньше суммы пополнения, ввиду дополнительных конвертаций в валюты  '
                                                 'других стран, так как прямого пополнения стим в РФ нет.\n\n'
                                                 f'Оплатите {user_summ}₽ на любую из представленных карт: \n\n'
                                                 '💳СберБанк: 2202203259212399\n'
                                                 '💳Тинькофф: 5536914196764892',)
            elif data['summ'] <= 99:
                async with state.proxy() as data:
                    await bot.send_message(message.from_user.id,
                                           text='Введите сумму от 100р:')
                    await state.reset()
        except ValueError:
            await bot.send_message(message.from_user.id,
                                   text='Введите число:')
            await state.reset()
    await state.finish()


def reg_client():
    dp.register_message_handler(start_message, commands='start')
    dp.register_message_handler(message_catalog)
    dp.register_callback_query_handler(callback_pay_steam, lambda c: c.data == 'pay_steam')
    dp.register_callback_query_handler(callback_qiwi, lambda c: c.data == 'qiwi')
    dp.register_message_handler(message_summ2, state=FSMsumm.summ2)
    dp.register_callback_query_handler(callback_card, lambda c: c.data == 'card')
    dp.register_message_handler(message_summ, state=FSMsumm)