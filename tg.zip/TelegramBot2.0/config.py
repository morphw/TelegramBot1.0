TOKEN = "5879458716:AAEFsKsITl-o8Dp0zKPXoImkeOEBG-CEKms"


INM_PHOTO = 'https://sun9-41.userapi.com/impg/xpPztZcLh8kyOEdZ6EqZAvuj4X0_vxRpCk4d3A/5e7BvLpCOyo.jpg?size=1920x1080&quality=95&sign=77c69a0e5b7f5f2e1b90065b98fd9400&type=album'
INM_STORE = 'https://sun9-57.userapi.com/impg/_2BCbACdveUzhfdQvcVb9TOsEBoYq6PTmjMgwA/QidbjPu7SUQ.jpg?size=1920x1080&quality=95&sign=17dec31a81c0ffd0edd77cef92008260&type=album'
INM_CATALOG = 'https://sun9-44.userapi.com/impg/OH4c7dhGrTNSZwN0rFE7SXpZkL7eKFaJtf_1VA/jh8c1VkR1LA.jpg?size=1280x720&quality=95&sign=45379b9cf485514b9a23d9ee3754d321&type=album'
INM_PAYMENT = 'https://sun9-84.userapi.com/impg/F5ayDH6xE_G_eDFIpDvmgUWY_tVJg7paj0rXRA/jcInT8B39cs.jpg?size=1920x1080&quality=95&sign=281f3fac5bd1fc657acf3224b8f3b136&type=album'
INM_CARD = 'https://sun9-17.userapi.com/impg/AWqavlBxMWqNQEg6fsmQz41y5K5Ir9ClyjM6hA/0Zfuvl6Es28.jpg?size=1280x720&quality=95&sign=0f9f4bcb2226e96dffdddbf7ceb029bb&type=album'
INM_INFO = 'https://sun9-65.userapi.com/impg/twITwLo6FJBMhp-pzPd_bt4mDAUFaYFQqhLSpQ/0SUBS4RftM4.jpg?size=1280x720&quality=95&sign=6c14cdd7fbd34be0571de18c52bca93a&type=album'
